package br.ulbra.menuhamburgueria;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastrarActivity extends AppCompatActivity {
    EditText edtUsuarioC, edtNome, edtSenha, edtSenha2;
    Button btCadastrar;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telacadastro);
        db = new DBHelper(this);

        edtUsuarioC = findViewById(R.id.edtUsuarioC);
        edtNome = findViewById(R.id.edtNome);
        edtSenha = findViewById(R.id.edtSenha);
        edtSenha2 = findViewById(R.id.edtSenha2);
        btCadastrar = findViewById(R.id.btCadastrar);

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nomeUsuario = edtUsuarioC.getText().toString().trim();
                String password1 = edtSenha.getText().toString().trim();
                String password2 = edtSenha2.getText().toString().trim();

                if (nomeUsuario.isEmpty()) {
                    Toast.makeText(CadastrarActivity.this, "Insira o LOGIN DO USUÁRIO", Toast.LENGTH_SHORT).show();
                } else if (password1.isEmpty() || password2.isEmpty()) {
                    Toast.makeText(CadastrarActivity.this, "Insira a SENHA DO USUÁRIO", Toast.LENGTH_SHORT).show();
                } else if (!password1.equals(password2)) {
                    Toast.makeText(CadastrarActivity.this, "As senhas não correspondem", Toast.LENGTH_SHORT).show();
                } else {
                    long res = db.criarUtilizador(nomeUsuario, password1);
                    if (res != -1) {
                        Toast.makeText(CadastrarActivity.this, "Registro OK", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(CadastrarActivity.this, "Usuário já existe ou erro ao registrar!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}

