# Projeto Menu de Hambúrgueria
-------------------------------------------------
Objetivo de Demonstrar suas funções de troca entre telas e imagens.

![P4 1](https://github.com/user-attachments/assets/2082aec3-6168-43c1-9909-ea3bc4f0bf0a)

![P4 2](https://github.com/user-attachments/assets/9c2a6c34-0116-4a9b-ab59-e5967dd67937)

![P4 3](https://github.com/user-attachments/assets/b6323192-b1c4-465a-93e7-1a53dae42407)

![P4 4](https://github.com/user-attachments/assets/97122d11-a4be-4eca-804b-0ed5ac6df326)

---------------------------------------------------
## O Que foi utilizado:

Backend: Java

---------------------------------------------------

## IDE:

Android Studio

---------------------------------------------------
## Autor:

https://github.com/Klaiancdrosa

---------------------------------------------------
## Comentário:

 Meu quarto projeto feito no Android Studio, esse projeto tem como objetivo demonstrar sua troca entre telas e
 imagens ao apertar dos botões laterais das imagens, tudo ainda parece meio feio, mas por enquanto está funcionando
 :sunglasses:
